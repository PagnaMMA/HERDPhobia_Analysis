# HERDPhobia: A dataset for Hate speech detection against Fulani Herdsmen in Nigeria.

 

# Description

This project creates a model for the detection of hate speech against the Fulani herdsmen in Nigeria. The collected tweets were annotated into 3 categories: hate (HT), non-hate (NHT) and indeterminate (IND). 

# Link to paper
https://arxiv.org/abs/2211.15262

# DOI
 	
https://doi.org/10.48550/arXiv.2211.15262


